<?php

    include 'dbconn.php';

        $parentcompany = $_POST["parentcompany"];
        $clientcompany =$_POST["clientcompany"];
        $country =$_POST['country'];
        $id = $_POST['id'];
        
        $sql = "UPDATE clientcompanydata SET parentcompany='".$parentcompany."',clientcompany='".$clientcompany."', country='".$country."'  WHERE id = '".$id."'";
        $conn->query($sql);

  
echo "<script>
        alert(' Client details edited succesfully'); 
        window.history.go(-2);
</script>";
?>
