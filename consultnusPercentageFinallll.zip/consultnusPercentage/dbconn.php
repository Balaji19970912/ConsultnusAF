<?php

$sername = "localhost";
$user = "root";
$pass = "";
$dbname = "nus_nus";

$conn = mysqli_connect($sername, $user, $pass, $dbname,3306);

if(!$conn) {
    echo "Connection Failed...!";
}
?>