<?php

include('dbconn.php');
session_start();

// $fullname = $_POST["fullname"];
$username = $_POST["emailId"];
$newpassword = $_POST["newpassword"];
$password = $_POST["confirmpassword"];

if($newpassword === $password) {
    $sql = "SELECT id FROM nususerdata WHERE emailId='$username'";
    $result = $conn->query($sql);
    
    if($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $newvalue = $row['id'];
    
            //$hashpass = password_hash($newpassword, PASSWORD_DEFAULT);
            $hash = password_hash($newpassword, PASSWORD_ARGON2I);
    
            $sql = "UPDATE nususerdata SET password='$hash' WHERE id='$newvalue'";
    
            if (mysqli_query($conn, $sql)) {
                // echo "Record updated successfully";
                header('Location: signin.php');
            } else {
                echo "Error updating record: " . mysqli_error($conn);
            }
    
    
        }
    } else {
        echo "No Data";
    }
    
} else {
    header("Location: index.php?error=Incorrect Username or Password has been entered...!");
}


?>