<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NUS FRS System | Sign-in</title>
    <link rel="icon" href="img/social-square-n-blue.png" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="wrapper">
            <header>
                <img src="img/nus-logo-2020-white@svg.svg" alt="NUS Consulting Group logo">
            </header>
            <section class="sectionContainerOne">
                <article class="secArticleOne">
                <p class="secArtiP">Welcome to <span class="spanBreak"></span> NUS Consulting Group’s<span class="spanBreak"></span> <strong>Flexible Reporting System (FRS)</strong> designed to provide dynamic position reports for flexible energy supply contracts.</p>
                <p>Remember your password? <a href="signin.php" style="color: #345DA6; font-weight: 500;">Sign in</a></p>    
            </article>
                <article class="secArticleTwo">
                    <form action="verifypassword.php" method="post">
                        <p class="secLogin">Please enter you login credentials</p>
                        <?php if (isset($_GET['error'])) {?>
                            <p class="error"><?php echo $_GET['error']; ?></p>
                        <?php }?>
                        <pre><img src="img/user.svg" alt="Username Logo" width="18x"> <input type="text" name="username" placeholder="Username" required/></pre>
                        <pre><img src="img/lock-key.svg" alt="Password Logo" width="18px"> <input type="password" name="newpassword" placeholder="New Password" required/></pre>
                        <pre><img src="img/lock-key.svg" alt="Password Logo" width="18px"> <input type="password" name="cnfpassword" placeholder="Confirm Password" required/></pre>
                        <input type="submit" class="signinButton" value="Submit" />
                    </form>
                </article>
            </section>
            <footer>
                <ul>
                    <li><a href="">NUS Consulting Group</a></li>
                    <li><a href="">Terms of Use</a></li>
                    <li><a href="">Privacy</a></li>
                </ul>
            </footer>
        </div>
    </div>
</body>
</html>